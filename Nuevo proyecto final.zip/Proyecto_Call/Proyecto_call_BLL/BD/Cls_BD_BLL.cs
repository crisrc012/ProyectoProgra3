﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto_call_DAL.BD;
using System.Configuration;
using System.Data.SqlClient;

namespace Proyecto_call_BLL.BD
{
    public class Cls_BD_BLL
    {

        public void Adapt(ref Cls_BD_DAL Obj_bd_DAL)
        {
            try
            {
                Obj_bd_DAL.scadena = ConfigurationManager.ConnectionStrings["Win_aut"].ToString().Trim();
                Obj_bd_DAL.Obj_conexion = new SqlConnection(Obj_bd_DAL.scadena);

                if (Obj_bd_DAL.Obj_conexion.State == System.Data.ConnectionState.Closed)
                {
                    Obj_bd_DAL.Obj_conexion.Open();
                    Obj_bd_DAL.Obj_adpt = new SqlDataAdapter(Obj_bd_DAL.ssentencia, Obj_bd_DAL.Obj_conexion);
                    Obj_bd_DAL.Obj_adpt.SelectCommand.CommandType = System.Data.CommandType.StoredProcedure;

                    Obj_bd_DAL.Obj_adpt.Fill(Obj_bd_DAL.dst, Obj_bd_DAL.snombretabla);
                }
                Obj_bd_DAL.smsjerror = string.Empty;
            }
            catch (SqlException e)
            {
                Obj_bd_DAL.smsjerror = e.ToString().Trim();
            }
            finally
            {
                if (Obj_bd_DAL.Obj_conexion != null)
                {
                    if (Obj_bd_DAL.Obj_conexion.State== System.Data.ConnectionState.Open)
                    {
                        Obj_bd_DAL.Obj_conexion.Close();
                    }
                    Obj_bd_DAL.Obj_conexion.Dispose();
                }
            }
        }
        public void Exe_NonQuery(ref Cls_BD_DAL Obj_bd_DAL)
        {

        }
        public void Exe_Scalar(ref Cls_BD_DAL Obj_bd_DAL)
        {

        }
    }
}
