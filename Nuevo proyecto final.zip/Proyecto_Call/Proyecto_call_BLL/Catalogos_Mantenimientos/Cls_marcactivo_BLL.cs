﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_call_BLL.Catalogos_Mantenimientos
{
    class Cls_marcactivo_BLL
    {
    }
}
