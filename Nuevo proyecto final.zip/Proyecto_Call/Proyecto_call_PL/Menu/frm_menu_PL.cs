﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Proyecto_call_BLL.Catalogos_Mantenimientos;
using Proyecto_call_DAL.Catalogos_Mantenimientos;

namespace Proyecto_call_PL.Menu
{
    public partial class frm_menu_PL : Form
    {
        public frm_menu_PL()
        {
            InitializeComponent();
        }


        private void tsm_ver_activo_Click(object sender, EventArgs e)
        {
            dtg_vistas.DataSource = null;
            Cls_activos_DAL Obj_activos_DAL = new Cls_activos_DAL();
            Cls_activos_BLL Obj_activos_BLL = new Cls_activos_BLL();

            Obj_activos_BLL.listar_activos(ref Obj_activos_DAL);

            if (Obj_activos_DAL.smsjError == string.Empty)
            {
                dtg_vistas.DataSource = null;
                dtg_vistas.DataSource = Obj_activos_DAL.Ds.Tables[0];
            }
            else
            {
                dtg_vistas.DataSource = null;
                MessageBox.Show(" Se presento el siguiente error " + Obj_activos_DAL.smsjError, "Error", MessageBoxButtons.OK);
            }
        }

        private void tsm_ver_casodetalle_Click(object sender, EventArgs e)
        {
            dtg_vistas.DataSource = null;
            Cls_casodetalle_DAL Obj_casodetalle_DAL = new Cls_casodetalle_DAL();
            Cls_casodetalle_BLL Obj_casodetalle_BLL = new Cls_casodetalle_BLL();

            Obj_casodetalle_BLL.listar_casodetalle(ref Obj_casodetalle_DAL);

            if (Obj_casodetalle_DAL.smsjError == string.Empty)
            {
                dtg_vistas.DataSource = null;
                dtg_vistas.DataSource = Obj_casodetalle_DAL.Ds.Tables[0];
            }
            else
            {
                dtg_vistas.DataSource = null;
                MessageBox.Show(" Se presento el siguiente error " + Obj_casodetalle_DAL.smsjError, "Error", MessageBoxButtons.OK);
            }
        }

        private void tsm_ver_casoencabezado_Click(object sender, EventArgs e)
        {
            dtg_vistas.DataSource = null;
            Cls_casoencabezado_DAL Obj_casoencabezado_DAL = new Cls_casoencabezado_DAL();
            Cls_casoencabezado_BLL Obj_casoencabezado_BLL = new Cls_casoencabezado_BLL();

            Obj_casoencabezado_BLL.listar_casoencabezado(ref Obj_casoencabezado_DAL);

            if (Obj_casoencabezado_DAL.smsjError == string.Empty)
            {
                dtg_vistas.DataSource = null;
                dtg_vistas.DataSource = Obj_casoencabezado_DAL.Ds.Tables[0];
            }
            else
            {
                dtg_vistas.DataSource = null;
                MessageBox.Show(" Se presento el siguiente error " + Obj_casoencabezado_DAL.smsjError, "Error", MessageBoxButtons.OK);
            }
        }
    }
}
